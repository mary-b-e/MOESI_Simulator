#define TRACE_LOAD 0
#define TRACE_STORE 1

#define PRINT_INTERVAL 100000

void parse_args();
void play_trace();
int read_trace_element();